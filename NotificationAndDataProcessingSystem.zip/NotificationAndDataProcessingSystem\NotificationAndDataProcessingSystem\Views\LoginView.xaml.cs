﻿using System.Windows;
using System.Windows.Controls;
using NotificationAndDataProcessingSystem.Auth;

namespace NotificationAndDataProcessingSystem.Views
{
    public partial class LoginView : UserControl
    {
        public LoginView()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text.Trim();
            string password = PasswordBox.Password;

            var user = AuthService.Login(username, password);

            if (user == null)
            {
                InfoTextBlock.Text = "Грешно потребителско име или парола.";
                return;
            }

            Session.CurrentUser = user;
            InfoTextBlock.Text = "";

            MessageBox.Show($"Успешен вход като {user.Role}.", "Успех",
                MessageBoxButton.OK, MessageBoxImage.Information);

            var mainWindow = Window.GetWindow(this) as MainWindow;
            mainWindow?.LoadDashboardAfterLogin();
        }
    }
}