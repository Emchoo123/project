﻿namespace NotificationAndDataProcessingSystem.Auth
{
    public enum UserRole
    {
        Admin,
        User
    }
}