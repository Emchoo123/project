﻿using System;
using NotificationAndDataProcessingSystem.Models;

namespace NotificationAndDataProcessingSystem.Services
{
    public class DelegateNotificationService
    {
        public Action<Notification>? NotificationSent;

        public void SendNotification(Notification notification)
        {
            NotificationSent?.Invoke(notification);
        }
    }
}