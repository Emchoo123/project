﻿using System;
using NotificationAndDataProcessingSystem.Models;

namespace NotificationAndDataProcessingSystem.Services
{
    public class EventNotificationService
    {
        public event Action<Notification>? NotificationSent;

        public void SendNotification(Notification notification)
        {
            NotificationSent?.Invoke(notification);
        }
    }
}