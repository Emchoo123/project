﻿namespace NotificationAndDataProcessingSystem.Models
{
    public class DataPointClass
    {
        public int Value { get; set; }

        public DataPointClass(int value)
        {
            Value = value;
        }
    }
}