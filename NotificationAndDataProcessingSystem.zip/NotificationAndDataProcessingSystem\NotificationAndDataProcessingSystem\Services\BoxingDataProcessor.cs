﻿using System.Collections;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace NotificationAndDataProcessingSystem.Services
{
    public class BoxingDataProcessor
    {
        public string ProcessData(int[] inputNumbers)
        {
            var stopwatch = Stopwatch.StartNew();

            ArrayList numbers = new ArrayList();

            foreach (int number in inputNumbers)
            {
                numbers.Add(number);
            }

            long sum = 0;
            int min = int.MaxValue;
            int max = int.MinValue;

            foreach (object item in numbers)
            {
                int value = (int)item;
                sum += value;

                if (value < min)
                    min = value;

                if (value > max)
                    max = value;
            }

            double average = numbers.Count > 0 ? (double)sum / numbers.Count : 0;

            stopwatch.Stop();

            var result = new StringBuilder();
            result.AppendLine("Режим: Boxing / Unboxing");
            result.AppendLine($"Брой числа: {numbers.Count}");
            result.AppendLine($"Сума: {sum}");
            result.AppendLine($"Средно: {average:F2}");
            result.AppendLine($"Минимум: {min}");
            result.AppendLine($"Максимум: {max}");
            result.AppendLine($"Време: {stopwatch.ElapsedMilliseconds} ms");

            return result.ToString();
        }
    }
}