﻿using System.Collections.Generic;
using System.Linq;

namespace NotificationAndDataProcessingSystem.Storage
{
    public class NotificationItem
    {
        public int Id { get; set; }
        public string RecipientUsername { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
        public bool IsRead { get; set; }

        public NotificationItem(int id, string recipientUsername, string title, string content)
        {
            Id = id;
            RecipientUsername = recipientUsername;
            Title = title;
            Content = content;
            IsRead = false;
        }
    }

    public static class NotificationStore
    {
        private static int _nextId = 1;

        public static List<NotificationItem> Notifications { get; } = new List<NotificationItem>();

        public static void Add(string recipientUsername, string title, string content)
        {
            Notifications.Add(new NotificationItem(_nextId++, recipientUsername, title, content));
        }

        public static List<NotificationItem> GetForUser(string username)
        {
            return Notifications
                .Where(n => n.RecipientUsername == username)
                .OrderByDescending(n => n.Id)
                .ToList();
        }

        public static int GetUnreadCount(string username)
        {
            return Notifications.Count(n => n.RecipientUsername == username && !n.IsRead);
        }

        public static void MarkAsRead(int id, string username)
        {
            var notification = Notifications.FirstOrDefault(n => n.Id == id && n.RecipientUsername == username);

            if (notification != null)
            {
                notification.IsRead = true;
            }
        }
    }
}