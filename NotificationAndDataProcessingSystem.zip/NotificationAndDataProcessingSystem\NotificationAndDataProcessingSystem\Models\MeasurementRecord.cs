﻿namespace NotificationAndDataProcessingSystem.Models
{
    public record MeasurementRecord(int Value);
}