﻿namespace NotificationAndDataProcessingSystem.Models
{
    public struct MeasurementStruct
    {
        public int Value { get; set; }

        public MeasurementStruct(int value)
        {
            Value = value;
        }
    }
}