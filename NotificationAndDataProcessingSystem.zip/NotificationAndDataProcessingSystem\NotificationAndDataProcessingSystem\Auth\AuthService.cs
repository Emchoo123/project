﻿using System.Collections.Generic;
using System.Linq;

namespace NotificationAndDataProcessingSystem.Auth
{
    public static class AuthService
    {
        private static List<UserAccount> users = new List<UserAccount>()
        {
            new UserAccount("admin", "admin123", UserRole.Admin),
            new UserAccount("user", "user123", UserRole.User)
        };

        public static List<UserAccount> Users => users;

        public static UserAccount? Login(string username, string password)
        {
            return users.FirstOrDefault(u =>
                u.Username == username && u.Password == password);
        }

        public static bool AddUser(string username, string password, UserRole role)
        {
            if (users.Any(u => u.Username.ToLower() == username.ToLower()))
                return false;

            users.Add(new UserAccount(username, password, role));
            return true;
        }
    }
}