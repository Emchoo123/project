﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using NotificationAndDataProcessingSystem.Auth;
using NotificationAndDataProcessingSystem.Services;
using NotificationAndDataProcessingSystem.Storage;

namespace NotificationAndDataProcessingSystem.Views
{
    public partial class DataProcessingView : UserControl
    {
        public DataProcessingView()
        {
            InitializeComponent();
            ConfigureByRole();
            LoadUserHistory();
        }

        private void ConfigureByRole()
        {
            if (Session.CurrentUser == null)
                return;

            if (Session.CurrentUser.Role == UserRole.Admin)
            {
                TitleTextBlock.Text = "Обработка на данни (Admin режим)";
                ModePanel.Visibility = Visibility.Visible;
            }
            else
            {
                TitleTextBlock.Text = "Обработка на данни";
                ModePanel.Visibility = Visibility.Collapsed;
            }
        }

        private void ProcessData_Click(object sender, RoutedEventArgs e)
        {
            if (Session.CurrentUser == null)
                return;

            string input = NumbersTextBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(input))
            {
                MessageBox.Show("Моля, въведи числа.", "Грешка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                int[] numbers = input
                    .Split(',', StringSplitOptions.RemoveEmptyEntries)
                    .Select(x => int.Parse(x.Trim()))
                    .ToArray();

                string result;
                string selectedMode;

                if (Session.CurrentUser.Role == UserRole.Admin)
                {
                    selectedMode = ((ComboBoxItem)ProcessingModeComboBox.SelectedItem).Content.ToString()!;

                    if (selectedMode == "Boxing")
                    {
                        var boxingProcessor = new BoxingDataProcessor();
                        result = boxingProcessor.ProcessData(numbers);
                    }
                    else
                    {
                        var unboxedProcessor = new UnboxedDataProcessor();
                        result = unboxedProcessor.ProcessData(numbers);
                    }
                }
                else
                {
                    selectedMode = "Standard";
                    var unboxedProcessor = new UnboxedDataProcessor();
                    result = unboxedProcessor.ProcessData(numbers);
                }

                ResultTextBox.Text = result;

                AppHistory.Add($"[{DateTime.Now:T}] DATA | {Session.CurrentUser.Username} | {selectedMode} | Обработени {numbers.Length} числа");
                DataProcessingStore.Add(Session.CurrentUser.Username, selectedMode, result);

                LoadUserHistory();
            }
            catch
            {
                MessageBox.Show("Моля, въведи само цели числа, разделени със запетая.",
                    "Невалидни данни",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void LoadUserHistory()
        {
            if (Session.CurrentUser == null)
                return;

            var userItems = DataProcessingStore.GetForUser(Session.CurrentUser.Username);

            if (userItems.Count == 0)
            {
                HistoryTextBox.Text = "Няма предишни обработки.";
                return;
            }

            HistoryTextBox.Text = string.Join(
                Environment.NewLine + Environment.NewLine,
                userItems
                    .Select(x => $"Режим: {x.Mode}{Environment.NewLine}{x.Result}")
                    .Reverse());
        }
    }
}