﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using NotificationAndDataProcessingSystem.Auth;
using NotificationAndDataProcessingSystem.Storage;

namespace NotificationAndDataProcessingSystem.Views
{
    public partial class UsersView : UserControl
    {
        public UsersView()
        {
            InitializeComponent();
            LoadUsers();
        }

        private void AddUserButton_Click(object sender, RoutedEventArgs e)
        {
            if (Session.CurrentUser == null || Session.CurrentUser.Role != UserRole.Admin)
            {
                MessageBox.Show("Само администратор може да добавя потребители.");
                return;
            }

            string username = UsernameTextBox.Text.Trim();
            string password = PasswordTextBox.Text.Trim();
            string selectedRole = ((ComboBoxItem)RoleComboBox.SelectedItem).Content.ToString()!;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Въведи потребителско име и парола.");
                return;
            }

            UserRole role = selectedRole == "Admin" ? UserRole.Admin : UserRole.User;

            bool success = AuthService.AddUser(username, password, role);

            if (!success)
            {
                MessageBox.Show("Потребител с това име вече съществува.");
                return;
            }

            AppHistory.Add($"[{DateTime.Now:T}] USER | Added {username} ({role})");

            UsernameTextBox.Clear();
            PasswordTextBox.Clear();

            LoadUsers();
            MessageBox.Show("Потребителят е добавен успешно.");
        }

        private void LoadUsers()
        {
            if (AuthService.Users.Count == 0)
            {
                UsersTextBox.Text = "Няма потребители.";
                return;
            }

            UsersTextBox.Text = string.Join(
                Environment.NewLine,
                AuthService.Users.Select(u => $"{u.Username} | {u.Role}")
            );
        }
    }
}