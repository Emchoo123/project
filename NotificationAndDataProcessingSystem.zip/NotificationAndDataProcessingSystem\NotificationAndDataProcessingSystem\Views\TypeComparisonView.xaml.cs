﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using NotificationAndDataProcessingSystem.Interfaces;
using NotificationAndDataProcessingSystem.Models;
using NotificationAndDataProcessingSystem.Services;
using NotificationAndDataProcessingSystem.Storage;

namespace NotificationAndDataProcessingSystem.Views
{
    public partial class TypeComparisonView : UserControl
    {
        public TypeComparisonView()
        {
            InitializeComponent();
        }

        private void StructTest_Click(object sender, RoutedEventArgs e)
        {
            var result = new StringBuilder();

            DataPointStruct pointStruct = new DataPointStruct(10);
            ModifyStruct(pointStruct);

            DataPointClass pointClass = new DataPointClass(10);
            ModifyClass(pointClass);

            result.AppendLine("1. Struct vs Class");
            result.AppendLine();
            result.AppendLine($"Struct value after method: {pointStruct.Value}");
            result.AppendLine($"Class value after method: {pointClass.Value}");
            result.AppendLine();
            result.AppendLine("Извод:");
            result.AppendLine("Struct се копира по стойност, затова оригиналният обект не се променя.");
            result.AppendLine("Class се подава по референция, затова промяната се запазва.");
            result.AppendLine("Това е важно при модели за данни в приложението.");

            ResultTextBox.Text = result.ToString();
            AppHistory.Add("[ANALYSIS] Struct vs Class executed");
        }

        private void InterfaceVsConcrete_Click(object sender, RoutedEventArgs e)
        {
            var result = new StringBuilder();

            INotifier interfaceNotifier = new EmailNotifier();
            EmailNotifier concreteNotifier = new EmailNotifier();

            result.AppendLine("2. Interface vs Concrete Class");
            result.AppendLine();
            result.AppendLine(interfaceNotifier.Send("Изпращане през интерфейс."));
            result.AppendLine("През интерфейс имаме достъп само до методите, дефинирани в INotifier.");
            result.AppendLine();

            result.AppendLine(concreteNotifier.Send("Изпращане през конкретен клас."));
            result.AppendLine(concreteNotifier.GetServerInfo());
            result.AppendLine("През конкретния клас имаме достъп и до допълнителни методи.");
            result.AppendLine();
            result.AppendLine("Извод:");
            result.AppendLine("Интерфейсът дава гъвкавост, а конкретният клас дава повече специфична функционалност.");

            ResultTextBox.Text = result.ToString();
            AppHistory.Add("[ANALYSIS] Interface vs Concrete executed");
        }

        private void StructClassInterface_Click(object sender, RoutedEventArgs e)
        {
            var result = new StringBuilder();

            ICalculator structCalculator = new StructCalculator();
            ICalculator classCalculator = new ClassCalculator();

            result.AppendLine("3. Struct/Class implementing Interface");
            result.AppendLine();
            result.AppendLine($"Struct result: {structCalculator.Calculate(5, 7)}");
            result.AppendLine($"Class result: {classCalculator.Calculate(5, 7)}");
            result.AppendLine();
            result.AppendLine("Извод:");
            result.AppendLine("И двата типа могат да имплементират интерфейс.");
            result.AppendLine("При struct е възможен boxing, когато се използва през интерфейс.");
            result.AppendLine("Class работи като референтен тип.");

            ResultTextBox.Text = result.ToString();
            AppHistory.Add("[ANALYSIS] Struct/Class with Interface executed");
        }

        private void StructVsRecord_Click(object sender, RoutedEventArgs e)
        {
            var result = new StringBuilder();

            MeasurementStruct s1 = new MeasurementStruct(10);
            MeasurementStruct s2 = s1;
            s2.Value = 20;

            MeasurementRecord r1 = new MeasurementRecord(10);
            MeasurementRecord r2 = r1 with { Value = 20 };

            result.AppendLine("4. Struct vs Record");
            result.AppendLine();
            result.AppendLine($"Struct: s1={s1.Value}, s2={s2.Value}");
            result.AppendLine($"Record: r1={r1.Value}, r2={r2.Value}");
            result.AppendLine();
            result.AppendLine("Извод:");
            result.AppendLine("Struct показва стандартно копиране по стойност.");
            result.AppendLine("Record позволява по-удобно копиране и immutable стил на работа.");
            result.AppendLine("Това е полезно за модели, които не трябва да се променят директно.");

            ResultTextBox.Text = result.ToString();
            AppHistory.Add("[ANALYSIS] Struct vs Record executed");
        }

        private void ClassVsRecord_Click(object sender, RoutedEventArgs e)
        {
            var result = new StringBuilder();

            User u1 = new User("Ivan", 20);
            User u2 = new User("Ivan", 20);

            UserRecord r1 = new UserRecord("Ivan", 20);
            UserRecord r2 = new UserRecord("Ivan", 20);

            result.AppendLine("5. Class vs Record");
            result.AppendLine();
            result.AppendLine($"Class equality: {u1 == u2}");
            result.AppendLine($"Record equality: {r1 == r2}");
            result.AppendLine();
            result.AppendLine("Извод:");
            result.AppendLine("Класовете обикновено се сравняват по референция.");
            result.AppendLine("Record типовете се сравняват по стойност.");
            result.AppendLine("Това ги прави удобни за модели на данни, DTO обекти и immutable структури.");

            ResultTextBox.Text = result.ToString();
            AppHistory.Add("[ANALYSIS] Class vs Record executed");
        }

        private void ModifyStruct(DataPointStruct point)
        {
            point.Value = 100;
        }

        private void ModifyClass(DataPointClass point)
        {
            point.Value = 100;
        }
    }
}