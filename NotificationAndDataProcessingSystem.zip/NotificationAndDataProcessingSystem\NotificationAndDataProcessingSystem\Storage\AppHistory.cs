﻿using System.Collections.Generic;

namespace NotificationAndDataProcessingSystem.Storage
{
    public static class AppHistory
    {
        public static List<string> Entries { get; } = new List<string>();

        public static void Add(string entry)
        {
            Entries.Add(entry);
        }
    }
}