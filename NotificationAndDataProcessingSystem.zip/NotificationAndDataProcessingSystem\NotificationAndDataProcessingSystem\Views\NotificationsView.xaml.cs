﻿using System;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using NotificationAndDataProcessingSystem.Auth;
using NotificationAndDataProcessingSystem.Interfaces;
using NotificationAndDataProcessingSystem.Models;
using NotificationAndDataProcessingSystem.Services;
using NotificationAndDataProcessingSystem.Storage;

namespace NotificationAndDataProcessingSystem.Views
{
    public partial class NotificationsView : UserControl
    {
        private readonly StringBuilder _logBuilder = new StringBuilder();
        private NotificationItem? _selectedNotification;

        public NotificationsView()
        {
            InitializeComponent();
            LoadByRole();
        }

        private void LoadByRole()
        {
            if (Session.CurrentUser == null)
                return;

            if (Session.CurrentUser.Role == UserRole.Admin)
            {
                AdminPanel.Visibility = Visibility.Visible;
                UserNotificationPanel.Visibility = Visibility.Collapsed;
                NotificationsTitleTextBlock.Text = "Изпратени известия";
                UnreadCountTextBlock.Text = "";
                MarkAsReadButton.Visibility = Visibility.Collapsed;
                LoadRecipients();
                LoadAdminNotifications();
            }
            else
            {
                AdminPanel.Visibility = Visibility.Collapsed;
                UserNotificationPanel.Visibility = Visibility.Visible;
                NotificationsTitleTextBlock.Text = "Получени известия";
                MarkAsReadButton.Visibility = Visibility.Visible;
                LoadUserNotifications();
            }
        }

        private void LoadRecipients()
        {
            RecipientComboBox.Items.Clear();

            var users = AuthService.Users
                .Where(u => u.Role == UserRole.User)
                .Select(u => u.Username)
                .ToList();

            foreach (var username in users)
            {
                RecipientComboBox.Items.Add(username);
            }

            if (RecipientComboBox.Items.Count > 0)
            {
                RecipientComboBox.SelectedIndex = 0;
            }
        }

        private void LoadAdminNotifications()
        {
            if (NotificationStore.Notifications.Count == 0)
            {
                LogTextBox.Text = "Няма изпратени известия.";
                return;
            }

            LogTextBox.Text = string.Join(
                Environment.NewLine + Environment.NewLine,
                NotificationStore.Notifications
                    .Select(n => $"До: {n.RecipientUsername}{Environment.NewLine}Заглавие: {n.Title}{Environment.NewLine}{n.Content}{Environment.NewLine}Статус: {(n.IsRead ? "Прочетено" : "Непрочетено")}")
                    .Reverse());
        }

        private void LoadUserNotifications()
        {
            if (Session.CurrentUser == null)
                return;

            var userNotifications = NotificationStore.GetForUser(Session.CurrentUser.Username);
            int unreadCount = NotificationStore.GetUnreadCount(Session.CurrentUser.Username);

            UnreadCountTextBlock.Text = $"Непрочетени: {unreadCount}";

            NotificationsListBox.ItemsSource = null;
            NotificationsListBox.ItemsSource = userNotifications
                .Select(n => new
                {
                    Display = n.IsRead ? n.Title : "[NEW] " + n.Title,
                    Item = n
                })
                .ToList();

            NotificationsListBox.DisplayMemberPath = "Display";

            if (userNotifications.Count == 0)
            {
                LogTextBox.Text = "Няма получени известия.";
                SelectedNotificationTextBox.Text = "";
                _selectedNotification = null;
                return;
            }

            LogTextBox.Text = $"Общо известия: {userNotifications.Count}";
        }

        private void SendNotification_Click(object sender, RoutedEventArgs e)
        {
            if (Session.CurrentUser == null || Session.CurrentUser.Role != UserRole.Admin)
            {
                MessageBox.Show("Само администратор може да изпраща известия.");
                return;
            }

            if (RecipientComboBox.SelectedItem == null)
            {
                MessageBox.Show("Няма избран получател.");
                return;
            }

            string recipient = RecipientComboBox.SelectedItem.ToString()!;
            string title = TitleTextBox.Text.Trim();
            string message = MessageTextBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(title) || string.IsNullOrWhiteSpace(message))
            {
                MessageBox.Show("Моля, въведи заглавие и съобщение.", "Грешка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string selectedChannel = ((ComboBoxItem)ChannelComboBox.SelectedItem).Content.ToString()!;

            INotifier notifier = selectedChannel == "Email"
                ? new EmailNotifier()
                : new SmsNotifier();

            var notification = new Notification(title, message);
            string historyEntry = "";
            string savedContent = "";

            if (selectedChannel == "Email")
            {
                var service = new EventNotificationService();

                service.NotificationSent += n =>
                {
                    string sentMessage = notifier.Send(n.ToString());
                    string line = $"[{DateTime.Now:T}] EVENT | Email | to {recipient} | {sentMessage}";
                    _logBuilder.AppendLine(line);
                    historyEntry = line;
                    savedContent = $"[{DateTime.Now:T}] {message} (Email, Event)";
                };

                service.SendNotification(notification);
            }
            else
            {
                var service = new DelegateNotificationService();

                service.NotificationSent += n =>
                {
                    string sentMessage = notifier.Send(n.ToString());
                    string line = $"[{DateTime.Now:T}] DELEGATE | SMS | to {recipient} | {sentMessage}";
                    _logBuilder.AppendLine(line);
                    historyEntry = line;
                    savedContent = $"[{DateTime.Now:T}] {message} (SMS, Delegate)";
                };

                service.SendNotification(notification);
            }

            if (!string.IsNullOrWhiteSpace(historyEntry))
            {
                AppHistory.Add(historyEntry);
            }

            if (!string.IsNullOrWhiteSpace(savedContent))
            {
                NotificationStore.Add(recipient, title, savedContent);
            }

            LoadAdminNotifications();

            TitleTextBox.Clear();
            MessageTextBox.Clear();
        }

        private void NotificationsListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selected = NotificationsListBox.SelectedItem;

            if (selected == null)
            {
                _selectedNotification = null;
                SelectedNotificationTextBox.Text = "";
                return;
            }

            var prop = selected.GetType().GetProperty("Item");
            _selectedNotification = prop?.GetValue(selected) as NotificationItem;

            if (_selectedNotification == null)
            {
                SelectedNotificationTextBox.Text = "";
                return;
            }

            SelectedNotificationTextBox.Text =
                $"Заглавие: {_selectedNotification.Title}{Environment.NewLine}{Environment.NewLine}" +
                $"{_selectedNotification.Content}{Environment.NewLine}{Environment.NewLine}" +
                $"Статус: {(_selectedNotification.IsRead ? "Прочетено" : "Непрочетено")}";
        }

        private void MarkAsReadButton_Click(object sender, RoutedEventArgs e)
        {
            if (Session.CurrentUser == null)
                return;

            if (_selectedNotification == null)
            {
                MessageBox.Show("Избери известие.");
                return;
            }

            int selectedId = _selectedNotification.Id;

            NotificationStore.MarkAsRead(selectedId, Session.CurrentUser.Username);
            AppHistory.Add($"[{DateTime.Now:T}] NOTIFICATION | {Session.CurrentUser.Username} | marked notification {selectedId} as read");

            LoadUserNotifications();

            var refreshed = NotificationStore
                .GetForUser(Session.CurrentUser.Username)
                .FirstOrDefault(n => n.Id == selectedId);

            _selectedNotification = refreshed;

            if (_selectedNotification != null)
            {
                SelectedNotificationTextBox.Text =
                    $"Заглавие: {_selectedNotification.Title}{Environment.NewLine}{Environment.NewLine}" +
                    $"{_selectedNotification.Content}{Environment.NewLine}{Environment.NewLine}" +
                    $"Статус: {(_selectedNotification.IsRead ? "Прочетено" : "Непрочетено")}";
            }
            else
            {
                SelectedNotificationTextBox.Text = "";
            }
        }
    }
}