﻿namespace NotificationAndDataProcessingSystem.Interfaces
{
    public interface ICalculator
    {
        int Calculate(int a, int b);
    }
}