﻿using System.Windows;
using NotificationAndDataProcessingSystem.Auth;
using NotificationAndDataProcessingSystem.Views;

namespace NotificationAndDataProcessingSystem
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ShowLogin();
        }

        private void ShowLogin()
        {
            Session.CurrentUser = null;
            UserInfoTextBlock.Text = "Not logged in";
            MainContent.Content = new LoginView();

            DashboardButton.IsEnabled = false;
            NotificationsButton.IsEnabled = false;
            DataProcessingButton.IsEnabled = false;
            UsersButton.IsEnabled = false;
            TypeComparisonButton.IsEnabled = false;
            ResultsButton.IsEnabled = false;
            LogoutButton.IsEnabled = false;
        }

        public void LoadDashboardAfterLogin()
        {
            if (Session.CurrentUser == null)
                return;

            UserInfoTextBlock.Text = $"{Session.CurrentUser.Username} ({Session.CurrentUser.Role})";
            MainContent.Content = new DashboardView();

            DashboardButton.IsEnabled = true;
            NotificationsButton.IsEnabled = true;
            DataProcessingButton.IsEnabled = true;
            LogoutButton.IsEnabled = true;

            if (Session.CurrentUser.Role == UserRole.Admin)
            {
                UsersButton.IsEnabled = true;
                TypeComparisonButton.IsEnabled = true;
                ResultsButton.IsEnabled = true;
            }
            else
            {
                UsersButton.IsEnabled = false;
                TypeComparisonButton.IsEnabled = false;
                ResultsButton.IsEnabled = false;
            }
        }

        private void DashboardButton_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new DashboardView();
        }

        private void NotificationsButton_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new NotificationsView();
        }

        private void DataProcessingButton_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new DataProcessingView();
        }

        private void UsersButton_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new UsersView();
        }

        private void TypeComparisonButton_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new TypeComparisonView();
        }

        private void ResultsButton_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new ResultsView();
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            ShowLogin();
        }
    }
}