﻿namespace NotificationAndDataProcessingSystem.Models
{
    public struct DataPointStruct
    {
        public int Value { get; set; }

        public DataPointStruct(int value)
        {
            Value = value;
        }
    }
}