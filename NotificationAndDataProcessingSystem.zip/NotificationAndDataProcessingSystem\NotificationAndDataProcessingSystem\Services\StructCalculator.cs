﻿using NotificationAndDataProcessingSystem.Interfaces;

namespace NotificationAndDataProcessingSystem.Services
{
    public struct StructCalculator : ICalculator
    {
        public int Calculate(int a, int b)
        {
            return a + b;
        }
    }
}