﻿using NotificationAndDataProcessingSystem.Interfaces;

namespace NotificationAndDataProcessingSystem.Services
{
    public class SmsNotifier : INotifier
    {
        public string Send(string message)
        {
            return $"SMS notifier: {message}";
        }
    }
}