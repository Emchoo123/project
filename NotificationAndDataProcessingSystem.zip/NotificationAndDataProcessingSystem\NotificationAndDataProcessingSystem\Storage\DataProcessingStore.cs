﻿using System.Collections.Generic;
using System.Linq;

namespace NotificationAndDataProcessingSystem.Storage
{
    public class DataProcessingItem
    {
        public string Username { get; set; }
        public string Mode { get; set; }
        public string Result { get; set; }

        public DataProcessingItem(string username, string mode, string result)
        {
            Username = username;
            Mode = mode;
            Result = result;
        }
    }

    public static class DataProcessingStore
    {
        public static List<DataProcessingItem> Items { get; } = new List<DataProcessingItem>();

        public static void Add(string username, string mode, string result)
        {
            Items.Add(new DataProcessingItem(username, mode, result));
        }

        public static List<DataProcessingItem> GetForUser(string username)
        {
            return Items
                .Where(x => x.Username == username)
                .ToList();
        }
    }
}