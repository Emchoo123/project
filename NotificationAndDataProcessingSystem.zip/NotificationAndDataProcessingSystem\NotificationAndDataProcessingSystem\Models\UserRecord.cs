﻿namespace NotificationAndDataProcessingSystem.Models
{
    public record UserRecord(string Name, int Age);
}