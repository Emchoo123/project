﻿using NotificationAndDataProcessingSystem.Interfaces;

namespace NotificationAndDataProcessingSystem.Services
{
    public class ClassCalculator : ICalculator
    {
        public int Calculate(int a, int b)
        {
            return a + b;
        }
    }
}