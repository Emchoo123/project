﻿using NotificationAndDataProcessingSystem.Interfaces;

namespace NotificationAndDataProcessingSystem.Services
{
    public class EmailNotifier : INotifier
    {
        public string Send(string message)
        {
            return $"Email notifier: {message}";
        }

        public string GetServerInfo()
        {
            return "SMTP server active";
        }
    }
}