﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace NotificationAndDataProcessingSystem.Services
{
    public class UnboxedDataProcessor
    {
        public string ProcessData(int[] inputNumbers)
        {
            var stopwatch = Stopwatch.StartNew();

            List<int> numbers = new List<int>();

            foreach (int number in inputNumbers)
            {
                numbers.Add(number);
            }

            long sum = 0;
            int min = int.MaxValue;
            int max = int.MinValue;

            foreach (int value in numbers)
            {
                sum += value;

                if (value < min)
                    min = value;

                if (value > max)
                    max = value;
            }

            double average = numbers.Count > 0 ? (double)sum / numbers.Count : 0;

            stopwatch.Stop();

            var result = new StringBuilder();
            result.AppendLine("Режим: Unboxed");
            result.AppendLine($"Брой числа: {numbers.Count}");
            result.AppendLine($"Сума: {sum}");
            result.AppendLine($"Средно: {average:F2}");
            result.AppendLine($"Минимум: {min}");
            result.AppendLine($"Максимум: {max}");
            result.AppendLine($"Време: {stopwatch.ElapsedMilliseconds} ms");

            return result.ToString();
        }
    }
}