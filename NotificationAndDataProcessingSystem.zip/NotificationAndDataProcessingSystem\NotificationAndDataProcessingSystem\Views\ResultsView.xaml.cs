﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using NotificationAndDataProcessingSystem.Auth;
using NotificationAndDataProcessingSystem.Storage;

namespace NotificationAndDataProcessingSystem.Views
{
    public partial class ResultsView : UserControl
    {
        public ResultsView()
        {
            InitializeComponent();
            ConfigureByRole();
            LoadHistory();
        }

        private void ConfigureByRole()
        {
            if (Session.CurrentUser == null)
                return;

            if (Session.CurrentUser.Role == UserRole.Admin)
            {
                TitleTextBlock.Text = "Пълна история на системата";
                ClearButton.IsEnabled = true;
                ClearButton.Visibility = Visibility.Visible;
            }
            else
            {
                TitleTextBlock.Text = "Моята история";
                ClearButton.IsEnabled = false;
                ClearButton.Visibility = Visibility.Collapsed;
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadHistory();
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            if (Session.CurrentUser == null || Session.CurrentUser.Role != UserRole.Admin)
            {
                MessageBox.Show("Само администратор може да изчиства историята.");
                return;
            }

            AppHistory.Entries.Clear();
            LoadHistory();
        }

        private void LoadHistory()
        {
            if (Session.CurrentUser == null)
                return;

            if (Session.CurrentUser.Role == UserRole.Admin)
            {
                if (AppHistory.Entries.Count == 0)
                {
                    HistoryTextBox.Text = "Все още няма записани действия.";
                    return;
                }

                HistoryTextBox.Text = string.Join(
                    Environment.NewLine + Environment.NewLine,
                    AppHistory.Entries.Reverse<string>());
            }
            else
            {
                var userEntries = AppHistory.Entries
                    .Where(x => x.Contains(Session.CurrentUser.Username))
                    .Reverse()
                    .ToList();

                if (userEntries.Count == 0)
                {
                    HistoryTextBox.Text = "Нямаш записани действия.";
                    return;
                }

                HistoryTextBox.Text = string.Join(
                    Environment.NewLine + Environment.NewLine,
                    userEntries);
            }
        }
    }
}