﻿namespace NotificationAndDataProcessingSystem.Interfaces
{
    public interface INotifier
    {
        string Send(string message);
    }
}