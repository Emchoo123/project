﻿namespace NotificationAndDataProcessingSystem.Auth
{
    public class UserAccount
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public UserRole Role { get; set; }

        public UserAccount(string username, string password, UserRole role)
        {
            Username = username;
            Password = password;
            Role = role;
        }
    }
}