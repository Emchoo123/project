﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using NotificationAndDataProcessingSystem.Auth;
using NotificationAndDataProcessingSystem.Storage;

namespace NotificationAndDataProcessingSystem.Views
{
    public partial class DashboardView : UserControl
    {
        public DashboardView()
        {
            InitializeComponent();
            LoadDashboard();
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadDashboard();
        }

        private void LoadDashboard()
        {
            if (Session.CurrentUser == null)
                return;

            int totalNotificationsCount = NotificationStore.Notifications.Count;
            int userNotificationsCount = NotificationStore
                .GetForUser(Session.CurrentUser.Username)
                .Count;

            int userUnreadNotificationsCount = NotificationStore
                .GetUnreadCount(Session.CurrentUser.Username);

            int totalProcessingCount = DataProcessingStore.Items.Count;
            int userProcessingCount = DataProcessingStore
                .GetForUser(Session.CurrentUser.Username)
                .Count;

            int totalActions = AppHistory.Entries.Count;

            if (Session.CurrentUser.Role == UserRole.Admin)
            {
                WelcomeTextBlock.Text = $"Добре дошъл, {Session.CurrentUser.Username} (Admin)";
                DescriptionTextBlock.Text = "Като администратор можеш да изпращаш известия, да обработваш данни, да виждаш историята и аналитичните сравнения.";

                Card1Title.Text = "Известия";
                Card1Value.Text = totalNotificationsCount.ToString();

                Card2Title.Text = "Обработки";
                Card2Value.Text = totalProcessingCount.ToString();

                Card3Title.Text = "Общо действия";
                Card3Value.Text = totalActions.ToString();
            }
            else
            {
                WelcomeTextBlock.Text = $"Добре дошъл, {Session.CurrentUser.Username} (User)";
                DescriptionTextBlock.Text = "Като потребител можеш да преглеждаш само своите известия и да използваш модула за обработка на данни.";

                Card1Title.Text = "Моите известия";
                Card1Value.Text = userNotificationsCount.ToString();

                Card2Title.Text = "Непрочетени";
                Card2Value.Text = userUnreadNotificationsCount.ToString();

                Card3Title.Text = "Моите обработки";
                Card3Value.Text = userProcessingCount.ToString();
            }
        }
    }
}