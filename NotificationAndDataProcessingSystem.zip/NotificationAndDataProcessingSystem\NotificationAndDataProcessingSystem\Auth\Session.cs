﻿namespace NotificationAndDataProcessingSystem.Auth
{
    public static class Session
    {
        public static UserAccount? CurrentUser { get; set; }
    }
}