﻿namespace NotificationAndDataProcessingSystem.Models
{
    public class Notification
    {
        public string Title { get; set; }
        public string Message { get; set; }

        public Notification(string title, string message)
        {
            Title = title;
            Message = message;
        }

        public override string ToString()
        {
            return $"{Title}: {Message}";
        }
    }
}